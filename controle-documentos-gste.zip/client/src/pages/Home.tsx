/**
 * Controle de Documentos de Engenharia da GSTE
 * 
 * Design: Industrial Dashboard — migração fiel do HTML original
 * Modificações: Removido filtro "Disciplina / Grupo Técnico", adicionado campo de busca por descrição
 */
import { useCallback, useEffect, useRef, useState } from "react";

// ============ TYPES ============
interface DocumentItem {
  titulo: string;
  descricao: string;
  escopo: string;
  fornecedor: string;
  statusRaw: string;
  statusCategory: string;
  dataAtualizacao: string;
  subestacaoName: string;
  fase: string;
  projeto: string;
  grupoTecnico: string;
}

interface ActiveFilters {
  project: string[];
  status: string[];
  substation: string[];
  phase: string[];
  scope: string[];
  vendor: string[];
  searchText: string;
}

interface SortState {
  column: string | null;
  asc: boolean;
}

// ============ CONSTANTS ============
const substationMap: Record<string, string> = {
  CID02: "SE Ceará Mirim",
  JPSE: "SE João Pessoa",
  SE5P1: "SE Pau Ferro",
  SE5G1: "SE Garanhuns",
  MSI08: "SE Messias",
  PLS: "SE Pilões",
  CAP3: "SE Capelinha 3",
  IBC: "SE Ibicoara",
  IGAP: "SE Igaporã",
  ITB5: "SE Itabira 5",
  JUSS: "SE Jussiape",
  SJP: "SE São João do Paraíso",
  OUR: "SE Ourolândia",
};

const statusConfig: Record<
  string,
  { label: string; className: string; hex: string }
> = {
  VERDE_CLARO: {
    label: "Aprovado / Comentários",
    className: "status-verde-claro",
    hex: "#28a745",
  },
  AZUL: { label: "Em Análise", className: "status-azul", hex: "#007bff" },
  AMARELO: { label: "Previsto", className: "status-amarelo", hex: "#ffc107" },
  VERDE_ESCURO: {
    label: "Liberado Execução",
    className: "status-verde-escuro",
    hex: "#155724",
  },
  LARANJA: {
    label: "Não Aprovado / Recusado",
    className: "status-laranja-escuro",
    hex: "#fd7e14",
  },
  ATRASADO: { label: "Atrasado", className: "status-vermelho", hex: "#dc3545" },
  OBSOLETO: {
    label: "Obsoleto / Cancelado",
    className: "status-roxo",
    hex: "#6f42c1",
  },
  OUTROS: { label: "Indefinido", className: "", hex: "#6c757d" },
};

// ============ HELPER FUNCTIONS ============
function tryParseDate(dateStr: string): Date | null {
  if (!dateStr) return null;
  dateStr = dateStr.trim();
  const partsBR = dateStr.match(/^(\d{2})\/(\d{2})\/(\d{4})/);
  if (partsBR)
    return new Date(
      parseInt(partsBR[3]),
      parseInt(partsBR[2]) - 1,
      parseInt(partsBR[1])
    );
  const partsISO = dateStr.match(/^(\d{4})-(\d{2})-(\d{2})/);
  if (partsISO)
    return new Date(
      parseInt(partsISO[1]),
      parseInt(partsISO[2]) - 1,
      parseInt(partsISO[3])
    );
  return null;
}

function extractScopeFromPath(path: string): string {
  if (!path) return "";
  const parts = path.split(/[/\\]/);
  const idx = parts.findIndex((p) => p.toLowerCase() === "doc_tecnicos");
  return idx !== -1 && idx + 1 < parts.length ? parts[idx + 1] : "";
}

function detectProject(text: string): string {
  const upperText = text.toUpperCase();
  for (const proj of ["GST001", "GST002", "GST003", "GST004"])
    if (upperText.includes(proj)) return proj;
  return "Outros";
}

function detectSubstation(text: string): { code: string; name: string } {
  const upperText = text.toUpperCase();
  for (const [code, name] of Object.entries(substationMap))
    if (upperText.includes(code)) return { code, name: `${code} - ${name}` };
  return { code: "OUTROS", name: "Outros / Geral" };
}

function detectPhase(text: string): string {
  const upperText = text.toUpperCase();
  if (upperText.includes("BAS")) return "Básico (BAS)";
  if (upperText.includes("EXE")) return "Executivo (EXE)";
  return "N/A";
}

function detectTechnicalGroup(desc: string): string {
  if (!desc) return "Geral / Outros";
  const d = desc
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "");
  if (
    d.includes("casa de comando") ||
    d.includes("edificacao") ||
    d.includes("casa de controle")
  )
    return "Casa de Comanda e Edificações";
  if (d.includes("terraplenagem")) return "Terraplenagem";
  if (d.includes("drenagem")) return "Drenagem";
  if (d.includes("malha") && (d.includes("terra") || d.includes("aterramento")))
    return "Malha de Terra";
  if (d.includes("fundacao") && d.includes("portico"))
    return "Fundações de Pórticos";
  const equipTerms = [
    "equipamento",
    "tc",
    "tp",
    "disjuntor",
    "seccionador",
    "bobina",
    "reator",
    " ip",
    "bloqueio",
  ];
  if (d.includes("fundacao") && equipTerms.some((term) => d.includes(term)))
    return "Fundação de Equipamento (TC, TP, Disjuntores e Chaves Seccionadores, IP, Bobinas de Bloqueio, Reatores a seco, Reatores a oleo)";
  if (d.includes("requisito") && d.includes("suporte"))
    return "Requisitos de Suportes de Equipamentos";
  if (d.includes("requisito") && d.includes("portico"))
    return "Requisitos de Pórticos";
  if (d.includes("detalhe") && d.includes("instalacao"))
    return "Detalhes de instalação de Equipamentos";
  return "Geral / Outros";
}

function categorizeStatus(status: string): string {
  if (!status) return "OUTROS";
  const s = status.toLowerCase().trim();
  if (s.includes("obsoleto") || s.includes("cancelado")) return "OBSOLETO";
  if (s.includes("atrasado")) return "ATRASADO";
  if (s.includes("aprovado") && !s.includes("não aprovado")) return "VERDE_CLARO";
  if (s.includes("liberado para execução")) return "VERDE_ESCURO";
  if (s.includes("análise") || s.includes("analise")) return "AZUL";
  if (s.includes("previsto")) return "AMARELO";
  if (s.includes("não aprovado") || s.includes("recusado")) return "LARANJA";
  return "OUTROS";
}

// ============ CSV PARSING ============
function parseCSVFile(
  file: File,
  encodingMode: string
): Promise<{ data: Record<string, string>[]; fields: string[] }> {
  return new Promise((resolve) => {
    const currentEncoding = encodingMode === "AUTO" ? "UTF-8" : encodingMode;

    // @ts-expect-error Papa is loaded from CDN
    Papa.parse(file, {
      header: true,
      delimiter: "",
      encoding: currentEncoding,
      skipEmptyLines: true,
      complete: function (results: {
        data: Record<string, string>[];
        meta: { fields: string[] };
      }) {
        if (encodingMode === "AUTO") {
          const headers = results.meta.fields || [];
          const firstRow = results.data[0] || {};
          const hasErrorChar =
            headers.some((h: string) => h.includes("\ufffd")) ||
            Object.values(firstRow).some(
              (v) => typeof v === "string" && v.includes("\ufffd")
            );
          if (hasErrorChar) {
            // @ts-expect-error Papa is loaded from CDN
            Papa.parse(file, {
              header: true,
              delimiter: "",
              encoding: "ISO-8859-1",
              skipEmptyLines: true,
              complete: function (retryResults: {
                data: Record<string, string>[];
                meta: { fields: string[] };
              }) {
                resolve({
                  data: retryResults.data,
                  fields: retryResults.meta.fields,
                });
              },
            });
            return;
          }
        }
        resolve({ data: results.data, fields: results.meta.fields });
      },
    });
  });
}

function processCSVData(
  data: Record<string, string>[],
  fields: string[]
): DocumentItem[] {
  return data.map((row) => {
    const keys = Object.keys(row);
    const getExact = (target: string): string => {
      const key = keys.find(
        (k) =>
          k
            .toLowerCase()
            .normalize("NFD")
            .replace(/[\u0300-\u036f]/g, "") === target
      );
      return key ? row[key] : "";
    };

    const titulo = getExact("titulo") || "";
    const descricao = getExact("descricao") || "";
    const statusRaw = getExact("estado atual") || getExact("status") || "";

    let latestDateStr = "";
    let latestDateObj: Date | null = null;
    if (fields && fields.length > 10) {
      for (let i = 10; i <= Math.min(fields.length - 1, 35); i++) {
        const val = row[fields[i]];
        const parsed = tryParseDate(val);
        if (parsed && (!latestDateObj || parsed > latestDateObj)) {
          latestDateObj = parsed;
          latestDateStr = val;
        }
      }
    }

    const subInfo = detectSubstation(titulo + " " + descricao);
    return {
      titulo,
      descricao,
      escopo:
        getExact("pasta") ||
        getExact("escopo") ||
        extractScopeFromPath(getExact("caminho")) ||
        "GERAL",
      fornecedor: getExact("autor") || getExact("fornecedor") || "",
      statusRaw,
      statusCategory: categorizeStatus(statusRaw),
      dataAtualizacao: latestDateStr,
      subestacaoName: subInfo.name,
      fase: detectPhase(titulo),
      projeto: detectProject(titulo),
      grupoTecnico: detectTechnicalGroup(descricao),
    };
  });
}

// ============ MULTISELECT COMPONENT ============
function MultiSelect({
  label,
  options,
  selected,
  onChange,
}: {
  label: string;
  options: { value: string; label: string }[];
  selected: string[];
  onChange: (values: string[]) => void;
}) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        setOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const buttonText =
    selected.length === 0
      ? "Todos"
      : selected.length === 1
        ? "1 Selecionado"
        : `${selected.length} Selecionados`;

  const toggleValue = (val: string) => {
    if (selected.includes(val)) {
      onChange(selected.filter((v) => v !== val));
    } else {
      onChange([...selected, val]);
    }
  };

  return (
    <div className="filter-group" ref={ref}>
      <label>{label}</label>
      <div className="multiselect-dropdown">
        <div
          className="multiselect-btn"
          onClick={(e) => {
            e.stopPropagation();
            setOpen(!open);
          }}
        >
          <span>{buttonText}</span>
        </div>
        {open && (
          <div className="multiselect-content show">
            {options.map((opt) => (
              <div
                key={opt.value}
                className="multiselect-option"
                onClick={() => toggleValue(opt.value)}
              >
                <input
                  type="checkbox"
                  checked={selected.includes(opt.value)}
                  onChange={() => toggleValue(opt.value)}
                  onClick={(e) => e.stopPropagation()}
                />
                <span>{opt.label}</span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

// ============ MAIN COMPONENT ============
export default function Home() {
  const [rawData, setRawData] = useState<DocumentItem[]>([]);
  const [filteredData, setFilteredData] = useState<DocumentItem[]>([]);
  const [dashboardVisible, setDashboardVisible] = useState(false);
  const [encoding, setEncoding] = useState("AUTO");
  const [sortState, setSortState] = useState<SortState>({
    column: null,
    asc: true,
  });
  const [filters, setFilters] = useState<ActiveFilters>({
    project: [],
    status: [],
    substation: [],
    phase: [],
    scope: [],
    vendor: [],
    searchText: "",
  });

  const pieChartRef = useRef<HTMLDivElement>(null);
  const barChartRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // ---- Filter options ----
  const getOptions = useCallback(
    (key: keyof DocumentItem) =>
      Array.from(new Set(rawData.map((item) => item[key]).filter((x) => x)))
        .sort()
        .map((v) => ({ value: v, label: v })),
    [rawData]
  );

  const statusOptions = Object.keys(statusConfig)
    .filter((k) => k !== "OUTROS")
    .map((k) => ({ value: k, label: statusConfig[k].label }));

  // ---- Apply filters ----
  useEffect(() => {
    if (rawData.length === 0) return;

    const searchLower = filters.searchText
      .toLowerCase()
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "");

    let result = rawData.filter((item) => {
      const matchProject =
        filters.project.length === 0 ||
        filters.project.includes(item.projeto);
      const matchStatus =
        filters.status.length === 0 ||
        filters.status.includes(item.statusCategory);
      const matchSubstation =
        filters.substation.length === 0 ||
        filters.substation.includes(item.subestacaoName);
      const matchPhase =
        filters.phase.length === 0 || filters.phase.includes(item.fase);
      const matchScope =
        filters.scope.length === 0 || filters.scope.includes(item.escopo);
      const matchVendor =
        filters.vendor.length === 0 ||
        filters.vendor.includes(item.fornecedor);
      const matchSearch =
        searchLower === "" ||
        item.descricao
          .toLowerCase()
          .normalize("NFD")
          .replace(/[\u0300-\u036f]/g, "")
          .includes(searchLower);

      return (
        matchProject &&
        matchStatus &&
        matchSubstation &&
        matchPhase &&
        matchScope &&
        matchVendor &&
        matchSearch
      );
    });

    // Sort
    if (sortState.column) {
      const col = sortState.column as keyof DocumentItem;
      result = [...result].sort((a, b) => {
        const valA = a[col] || "";
        const valB = b[col] || "";

        if (col === "dataAtualizacao") {
          const dateA = tryParseDate(valA) || new Date(0);
          const dateB = tryParseDate(valB) || new Date(0);
          return sortState.asc
            ? dateA.getTime() - dateB.getTime()
            : dateB.getTime() - dateA.getTime();
        }

        const comparison = String(valA).localeCompare(String(valB), "pt-BR", {
          sensitivity: "base",
        });
        return sortState.asc ? comparison : -comparison;
      });
    }

    setFilteredData(result);
  }, [rawData, filters, sortState]);

  // ---- Render charts ----
  useEffect(() => {
    if (filteredData.length === 0 || !pieChartRef.current || !barChartRef.current)
      return;

    // @ts-expect-error Highcharts loaded from CDN
    if (typeof Highcharts === "undefined") return;

    const counts: Record<string, number> = {};
    Object.keys(statusConfig).forEach((key) => (counts[key] = 0));
    filteredData.forEach((item) => {
      counts[item.statusCategory]++;
    });

    const pieData = Object.keys(statusConfig)
      .filter((k) => counts[k] > 0)
      .map((k) => ({
        name: statusConfig[k].label,
        y: counts[k],
        color: statusConfig[k].hex,
      }));

    // @ts-expect-error Highcharts loaded from CDN
    Highcharts.chart(pieChartRef.current, {
      chart: {
        type: "pie",
        options3d: { enabled: true, alpha: 45, beta: 0 },
      },
      title: { text: "Distribuição por Status" },
      plotOptions: {
        pie: {
          depth: 35,
          dataLabels: { enabled: true, format: "{point.name}: {point.y}" },
        },
      },
      series: [{ name: "Documentos", data: pieData }],
      credits: { enabled: false },
    });

    const scopes = Array.from(new Set(filteredData.map((d) => d.escopo))).sort();
    const seriesLib = scopes.map(
      (s) =>
        filteredData.filter(
          (d) => d.escopo === s && d.statusCategory === "VERDE_ESCURO"
        ).length
    );
    const seriesRest = scopes.map(
      (s, i) =>
        filteredData.filter((d) => d.escopo === s).length - seriesLib[i]
    );

    // @ts-expect-error Highcharts loaded from CDN
    Highcharts.chart(barChartRef.current, {
      chart: { type: "column" },
      title: { text: "% Avanço (Liberado para Execução)" },
      xAxis: { categories: scopes, labels: { rotation: -45 } },
      yAxis: { min: 0, title: { text: "Quantidade" } },
      plotOptions: { column: { stacking: "percent" } },
      series: [
        { name: "Restante", data: seriesRest, color: "#ffc107" },
        { name: "Liberado", data: seriesLib, color: "#198754" },
      ],
      credits: { enabled: false },
    });
  }, [filteredData]);

  // ---- File upload ----
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    let allData: DocumentItem[] = [];

    for (let i = 0; i < files.length; i++) {
      const { data, fields } = await parseCSVFile(files[i], encoding);
      const processed = processCSVData(data, fields);
      allData = allData.concat(processed);
    }

    setRawData(allData);
    setDashboardVisible(true);
  };

  // ---- Sort handler ----
  const handleSort = (column: string) => {
    setSortState((prev) => ({
      column,
      asc: prev.column === column ? !prev.asc : true,
    }));
  };

  // ---- Reset filters ----
  const resetFilters = () => {
    setFilters({
      project: [],
      status: [],
      substation: [],
      phase: [],
      scope: [],
      vendor: [],
      searchText: "",
    });
  };

  // ---- Delete obsolete ----
  const deleteObsolete = () => {
    const countBefore = rawData.length;
    const newData = rawData.filter((item) => item.statusCategory !== "OBSOLETO");
    if (countBefore - newData.length > 0) {
      alert(`${countBefore - newData.length} itens removidos.`);
      setRawData(newData);
    } else {
      alert("Nenhum item obsoleto encontrado.");
    }
  };

  // ---- Sort icon ----
  const getSortIcon = (column: string) => {
    if (sortState.column !== column) return "⇅";
    return sortState.asc ? "▲" : "▼";
  };

  // ---- Update a single filter ----
  const updateFilter = (key: keyof ActiveFilters, values: string[]) => {
    setFilters((prev) => ({ ...prev, [key]: values }));
  };

  return (
    <div className="gste-app">
      <div className="container">
        {/* UPLOAD CARD */}
        <div className="card">
          <h1>Controle de Documentos de Engenharia da GSTE</h1>

          <div className="upload-controls">
            <div>
              <label
                htmlFor="encodingSelect"
                style={{ fontWeight: "bold", marginRight: 5 }}
              >
                Codificação:
              </label>
              <select
                id="encodingSelect"
                value={encoding}
                onChange={(e) => setEncoding(e.target.value)}
                style={{
                  padding: 5,
                  borderRadius: 4,
                  border: "1px solid #ccc",
                }}
              >
                <option value="AUTO">Automático (Recomendado)</option>
                <option value="UTF-8">UTF-8 (Padrão Novo)</option>
                <option value="ISO-8859-1">Latin1 (Padrão Antigo)</option>
              </select>
            </div>
          </div>

          <div
            className="upload-area"
            onClick={() => fileInputRef.current?.click()}
          >
            <h3>Clique para fazer Upload dos Arquivos (CSV)</h3>
            <p>Ordenação disponível clicando nos títulos das colunas</p>
            <input
              ref={fileInputRef}
              type="file"
              accept=".csv,.json"
              multiple
              onChange={handleFileUpload}
              style={{ display: "none" }}
            />
          </div>
        </div>

        {/* DASHBOARD CARD */}
        {dashboardVisible && (
          <div className="card">
            <div className="filters-container">
              <MultiSelect
                label="Projeto"
                options={getOptions("projeto")}
                selected={filters.project}
                onChange={(v) => updateFilter("project", v)}
              />
              <MultiSelect
                label="Status"
                options={statusOptions}
                selected={filters.status}
                onChange={(v) => updateFilter("status", v)}
              />
              <MultiSelect
                label="Subestação"
                options={getOptions("subestacaoName")}
                selected={filters.substation}
                onChange={(v) => updateFilter("substation", v)}
              />
              <MultiSelect
                label="Fase"
                options={getOptions("fase")}
                selected={filters.phase}
                onChange={(v) => updateFilter("phase", v)}
              />
              <MultiSelect
                label="Escopo (Pasta)"
                options={getOptions("escopo")}
                selected={filters.scope}
                onChange={(v) => updateFilter("scope", v)}
              />
              <MultiSelect
                label="Fornecedor"
                options={getOptions("fornecedor")}
                selected={filters.vendor}
                onChange={(v) => updateFilter("vendor", v)}
              />

              {/* CAMPO DE BUSCA POR DESCRIÇÃO */}
              <div className="filter-group" style={{ minWidth: 280 }}>
                <label>Buscar por Descrição</label>
                <div style={{ position: "relative" }}>
                  <input
                    type="text"
                    placeholder="Digite para filtrar pela descrição..."
                    value={filters.searchText}
                    onChange={(e) =>
                      setFilters((prev) => ({
                        ...prev,
                        searchText: e.target.value,
                      }))
                    }
                    className="search-input"
                  />
                  {filters.searchText && (
                    <button
                      className="search-clear-btn"
                      onClick={() =>
                        setFilters((prev) => ({ ...prev, searchText: "" }))
                      }
                      title="Limpar busca"
                    >
                      ✕
                    </button>
                  )}
                </div>
              </div>

              <div
                className="filter-group"
                style={{ flexDirection: "row", gap: 10 }}
              >
                <button className="clear-btn" onClick={resetFilters}>
                  Limpar Filtros
                </button>
                <button className="delete-btn" onClick={deleteObsolete}>
                  Excluir Obsoletos/Cancelados
                </button>
              </div>
            </div>

            <hr
              style={{
                margin: "20px 0",
                border: 0,
                borderTop: "1px solid #eee",
              }}
            />

            <div className="charts-row">
              <div ref={pieChartRef} className="chart-container"></div>
              <div ref={barChartRef} className="chart-container"></div>
            </div>
          </div>
        )}

        {/* TABLE CARD */}
        {dashboardVisible && (
          <div className="card">
            <div className="stats-summary">
              <span>Total: {rawData.length}</span>
              <span>Exibindo: {filteredData.length}</span>
            </div>
            <div className="table-responsive">
              <table>
                <thead>
                  <tr>
                    <th
                      data-column="titulo"
                      onClick={() => handleSort("titulo")}
                    >
                      Título{" "}
                      <span className="sort-icon">{getSortIcon("titulo")}</span>
                    </th>
                    <th
                      data-column="descricao"
                      onClick={() => handleSort("descricao")}
                    >
                      Descrição{" "}
                      <span className="sort-icon">
                        {getSortIcon("descricao")}
                      </span>
                    </th>
                    <th
                      data-column="escopo"
                      onClick={() => handleSort("escopo")}
                    >
                      Escopo{" "}
                      <span className="sort-icon">{getSortIcon("escopo")}</span>
                    </th>
                    <th
                      data-column="fornecedor"
                      onClick={() => handleSort("fornecedor")}
                    >
                      Fornecedor{" "}
                      <span className="sort-icon">
                        {getSortIcon("fornecedor")}
                      </span>
                    </th>
                    <th
                      data-column="subestacaoName"
                      onClick={() => handleSort("subestacaoName")}
                    >
                      Subestação{" "}
                      <span className="sort-icon">
                        {getSortIcon("subestacaoName")}
                      </span>
                    </th>
                    <th
                      data-column="statusRaw"
                      onClick={() => handleSort("statusRaw")}
                    >
                      Status{" "}
                      <span className="sort-icon">
                        {getSortIcon("statusRaw")}
                      </span>
                    </th>
                    <th
                      data-column="dataAtualizacao"
                      onClick={() => handleSort("dataAtualizacao")}
                    >
                      Última Atualização{" "}
                      <span className="sort-icon">
                        {getSortIcon("dataAtualizacao")}
                      </span>
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {filteredData.map((item, idx) => {
                    const config =
                      statusConfig[item.statusCategory] ||
                      statusConfig["OUTROS"];
                    return (
                      <tr key={idx} className={config.className}>
                        <td>{item.titulo}</td>
                        <td>{item.descricao}</td>
                        <td>{item.escopo}</td>
                        <td>{item.fornecedor}</td>
                        <td>{item.subestacaoName}</td>
                        <td>{item.statusRaw}</td>
                        <td>{item.dataAtualizacao}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
